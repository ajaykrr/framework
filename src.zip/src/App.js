

import Company from './components/Company';
import Access from './components/Access';
import Login from './components/Login';
import { BrowserRouter,Routes, Route, Link, Navigate } from 'react-router-dom';
function App() {
  return (
    <div className="App">
        <BrowserRouter>
  
      

  <Routes>
 
     
      <Route path="/" element={<Company/>} />
      <Route path="/A" element={< Access/>} />
      <Route path="/L" element={< Login/>} />
  </Routes>
  
</BrowserRouter>
     
    </div>
  );
}

export default App;
