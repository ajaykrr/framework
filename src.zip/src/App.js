

import Company from './components/Company';
import Access from './components/Access';
import { BrowserRouter,Routes, Route, Link, Navigate } from 'react-router-dom';
function App() {
  return (
    <div className="App">
        <BrowserRouter>
  
      

  <Routes>
 
     
      <Route path="/" element={<Company/>} />
      <Route path="/A" element={< Access/>} />
  </Routes>
  
</BrowserRouter>
     
    </div>
  );
}

export default App;
