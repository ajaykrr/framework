
// import './Access.css'
import "bootstrap/dist/css/bootstrap.min.css";
import { Form, Button,Col,Row } from "react-bootstrap";
import React, {  useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
function Access() {
  const[type,settype]=useState()
  const[service,setservice]=useState()
  const[funct,setfunct]=useState()
  const[Rname,setRname]=useState()
  const[Access,setAccess]=useState()
  const[Dataaccess,setDataaccess]=useState()
  const[company,setcompany]=useState()

  function handlechange(e){
    e.preventDefault();
    console.log(type);
    if(type==null){
      alert("null")
    }
    setservice(e.target.value)
   

  }

    return (

<div className='containerProfile'>
<div className='formProfile'>
    
<Form>
<Row className="mb-3">
<Form.Group as={Col} controlId="formGridState">
      <Form.Label>Type</Form.Label>
      <Form.Select defaultValue="Choose..." onChange={(e)=>settype(e.target.value)}>
        <option></option>
        <option value="delete">delete</option>
      <option value="create">create</option>
       <option value="update">update</option>
      </Form.Select>
    </Form.Group>
   
    <Form.Group as={Col} controlId="formGridCity">
      <Form.Label>Service</Form.Label>
      <Form.Control value={service} onFocus={(e)=>{handlechange(e)}}/>
    </Form.Group>

    

    <Form.Group as={Col} controlId="formGridZip">
      <Form.Label>Function</Form.Label>
      <Form.Control value={funct} onChange={(e)=>setfunct(e.target.value)}/>
    </Form.Group>
  </Row>
<Form.Group className="mb-3" controlId="formBasicAddress">
<Form.Label>Role Name</Form.Label>
<Form.Select aria-label="Default select example" value={Rname} onChange={(e)=>setRname(e.target.value)}>
<option>Open this select menu</option>
<option value="1">One</option>
<option value="2">Two</option>
<option value="3">Three</option>
</Form.Select>
</Form.Group>

<Form.Group className="mb-3" controlId="formBasicAddress">
<Form.Label>Access</Form.Label>
<Form.Select aria-label="Default select example" value={Access} onChange={(e)=>setAccess(e.target.value)}>
<option>Open this select menu</option>
<option value="1">One</option>
<option value="2">Two</option>
<option value="3">Three</option>
</Form.Select>
</Form.Group>
<Form.Group className="mb-3" controlId="formBasicAddress" value={Dataaccess} onChange={(e)=>setDataaccess(e.target.value)}>
<Form.Label>Data Access</Form.Label>
<Form.Select aria-label="Default select example">
<option>Open this select menu</option>
<option value="1">One</option>
<option value="2">Two</option>
<option value="3">Three</option>
</Form.Select>
</Form.Group>
<Form.Group className="mb-3" controlId="formBasicAddress" >
<Form.Label>Company</Form.Label>
<Form.Select aria-label="Default select example" value={company} onChange={(e)=>setcompany(e.target.value)}>
<option>Open this select menu</option>
<option value="ibm">ibm</option>
<option value="tcs">tcs</option>
<option value="3">Three</option>
</Form.Select>
</Form.Group>

<Button variant="primary" type="submit">
Submit
</Button>
</Form>
</div>
</div>
    )
}

export default Access