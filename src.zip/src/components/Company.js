
import "bootstrap/dist/css/bootstrap.min.css";
import './Company.css'
import axios from "axios";
import React, {  useState } from "react";
import { v4 as uuidv4 } from 'uuid';
import { useNavigate } from "react-router-dom";
function Company() {
  const[name,setname]=useState()
  const[Address,setAddress]=useState()
  let navigate = useNavigate();
  function insert()
  {
  var Pk=uuidv4();
  console.log(Pk)
  var i="P#";
  var Sk=i.concat( Pk);
 
   var dt={
    "TableName":"tnts",
        "Item":{
            "Pk":Pk,
            "Sk":Sk,
            "tnm":name,
           " tdaddr":Address,
           "tsaddr":Address

         
          
        }
    }
    axios
    .post('http://localhost:8000/insert',dt)
    .then(() => {console.log(' Created')
    alert("saved")
    navigate("/");

  })
    
    .catch(err => {
      console.error(err);
    });

  }
  return (
    <div>
        <div class="Namebox ">
          <div class="element">
            <label for="Uname" class="form-label">
             Name
            </label>
            <input
              type="text"
              class="form-control"
              id="Uname"
             value={name}
             onChange={(e)=>setname(e.target.value)}
             
            ></input>
          </div>
          <div class="element">
            <label for="Password" class="form-label">
              Address
            </label>
            <input
              type="text"
              class="form-control"
              value={Address}
              id="Pass"
              onChange={(e)=>setAddress(e.target.value)}
            ></input>
            <button onClick={insert}>Save</button>
  </div>
  </div>
    </div>
  )
}

export default Company