
import './Login.css'
import { Form, Button} from "react-bootstrap";
import React, {  useState,useEffect} from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
function Login() {
  
    const [username, setUsername]=useState('');
    const [password , setPassword]=useState('');
    const [token, setToken]=useState('');
    
    let navigate = useNavigate();

   


    const handleGetButton=(e)=>{
        e.preventDefault();
        let reqst={"username":username, "password":password};
        let url="http://localhost:8000/getdata";
        let header={ Authorization: `Bearer ${token}`};
        console.log("req=>"+JSON.stringify(reqst));
        console.log("url=>"+url);
        axios.post(
            url,reqst, {headers:header}
        ).then(
            (res)=>{
                console.log(res.data) 
            }
        ).catch();
    }

    function HandleClick(e){
        e.preventDefault();
        let reqst={"username":username, "password":password};
        let url="http://localhost:8000/logincheck";
        let header={ };
        console.log("req=>"+JSON.stringify(reqst));
        console.log("url=>"+url);
        axios.post(
            url,reqst,header
        ).then(
            (res)=>{
                console.log(res.data)
                setToken(res.data.token);
                alert("Login ")
                navigate("/");
            }
        ).catch();
    }
  return (
    <div className="login"><Form>
    <Form.Group className="mb-3" controlId="formBasicEmail">
      <Form.Label>UserName</Form.Label>
      <Form.Control type="Text" placeholder="UserName" onChange={(e)=>setUsername(e.target.value)} />
     
    </Form.Group>
  
    <Form.Group className="mb-3" controlId="formBasicPassword">
      <Form.Label>Password</Form.Label>
      <Form.Control type="password" placeholder="Password"onChange={(e)=>setPassword(e.target.value)}  />
    </Form.Group>
    
    <Button variant="primary" type="submit" onClick={(e)=>HandleClick(e)}>
      Login
    </Button>
    {/* <Button variant="primary" type="submit" onClick={(e)=>{handleGetButton(e)}}>
      get
    </Button> */}
    {/* <button onClick={handleGetButton}>GetData</button> */}
  </Form></div>
  )
}

export default Login